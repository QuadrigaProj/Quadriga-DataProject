"""API 스모크 테스트 — 담당 D

실행:
    pytest -q

서버를 따로 띄우지 않아도 된다. FastAPI TestClient 가 앱을 직접 호출한다.
프론트(담당 C)가 기대하는 응답 모양이 깨지지 않았는지 확인하는 것이 목적이다.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from api.main import app  # noqa: E402

client = TestClient(app)

ADULT = {"age_gbn": "성인", "sex": "M", "flexibility": 8.0, "strength": 25,
         "height_cm": 175, "weight_kg": 74}


def data_ready() -> bool:
    h = client.get("/health").json()
    return h["분포_로드됨"] and h["처방_로드됨"]


needs_data = pytest.mark.skipif(
    not data_ready(), reason="분포/처방 데이터 없음 — /health 안내 참고"
)


def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["ok"] is True


def test_purposes():
    """목적 6종은 데이터 없이도 떠야 한다 (화면 2가 먼저 로드된다)."""
    r = client.get("/purposes")
    assert r.status_code == 200
    body = r.json()
    assert len(body) == 6
    assert {"목적", "우선요인"} <= set(body[0])


@needs_data
def test_fitness_age_성인():
    r = client.post("/fitness-age", json=ADULT)
    assert r.status_code == 200
    b = r.json()
    assert 10 < b["체력나이"] < 100
    assert b["신뢰구간"] > 0
    assert {"유연성", "근력", "체성분"} <= set(b["항목별"])
    assert b["약점"]["약점"] in b["항목별"]


@needs_data
def test_fitness_age_어르신():
    r = client.post("/fitness-age",
                    json={"age_gbn": "어르신", "sex": "F",
                          "flexibility": 10.0, "strength": 18, "bmi": 23.5})
    assert r.status_code == 200
    assert r.json()["체력나이"] > 50


@needs_data
def test_bmi_는_양방향_편차():
    """저체중도 과체중처럼 불리하게 잡혀야 한다 (BMI 는 U 자형)."""
    def 체성분(bmi):
        r = client.post("/fitness-age",
                        json={"age_gbn": "성인", "sex": "M", "bmi": bmi})
        return r.json()["항목별"]["체성분"]

    assert 체성분(16.0) > 체성분(22.0)
    assert 체성분(30.0) > 체성분(22.0)


def test_측정값_없으면_400():
    r = client.post("/fitness-age", json={"age_gbn": "성인", "sex": "M"})
    assert r.status_code == 400


def test_없는_연령군은_422():
    r = client.post("/fitness-age",
                    json={"age_gbn": "유아", "sex": "M", "strength": 25})
    assert r.status_code == 422


@needs_data
def test_routine_순서():
    r = client.get("/routine", params={"age_gbn": "성인", "sex": "M",
                                       "purpose": "다이어트",
                                       "weak_factor": "근력"})
    assert r.status_code == 200
    steps = r.json()
    assert [s["단계"] for s in steps] == sorted(
        [s["단계"] for s in steps],
        key=lambda x: ["준비운동", "본운동", "정리운동"].index(x))
    assert steps[0]["단계"] == "준비운동"
    assert steps[-1]["단계"] == "정리운동"


@needs_data
def test_recheck_변화량():
    r = client.post("/recheck", json={
        "이전": ADULT,
        "현재": {**ADULT, "flexibility": 12.0, "strength": 32, "weight_kg": 72},
    })
    assert r.status_code == 200
    b = r.json()
    assert b["변화"] == round(b["현재"] - b["이전"], 1)
    assert b["변화"] < 0          # 측정값이 좋아졌으니 체력나이는 내려가야 한다
